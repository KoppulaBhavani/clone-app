import {RES_URL} from "../utilits/constants";
const RestaurantCard=(props) =>{
    const {RestData } = props;
    const {
        name,
        cloudinaryImageId,
        areaName,
        costForTwo,
        cuisines,
        avgRating,
        sla,
    } =  RestData.info;

    
    return(
        <div className="res-card">
            <img src={RES_URL+ cloudinaryImageId}
            alt=""
            width="250"
            height="180"
            className="res-img"/>
            <div style={{paddingLeft:"8px"}}>
                <h4 className="res_title">{name.slice(0,20)}{name.length>20 ? '...':''} </h4>
                <div className="space cost">{costForTwo}</div>
                <div className="space cost ">⭐{avgRating}.{sla.slaString}</div>
                
                <div className="space cusinies">{cuisines.join(", ") .slice(0, 32)}{cuisines.length>3 ? "...":''} </div>
                <div className="space cusinies">{areaName}</div>

            </div>

        </div>
    )
}

export default RestaurantCard;