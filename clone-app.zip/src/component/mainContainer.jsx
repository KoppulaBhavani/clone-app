import RestaurantCard from "./Restaurantcard";
//import {resList} from "../utilits/data";
import { useEffect, useState } from "react";
import Shimmer from "./Shimmer";

const MainContent = () => {
  const [listOfRestaurant,setListOfRestauratnt] = useState([]);
  const [filteredRes,setFilteredRes] = useState([])
  const [searchInput , setSearchInput] = useState('');

useEffect(()=>{
  fetchData()
},[])

const fetchData =async() =>{
  const data =await fetch("https://www.swiggy.com/dapi/restaurants/list/v5?lat=18.53914&lng=73.9046867&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING");
  const res = await data.json();
  console.log(res);
  setListOfRestauratnt(res?.data?.cards[1]?.card?.card?.gridElements?.infoWithStyle?.restaurants);
  setFilteredRes(
    res?.data?.cards[1]?.card?.card?.gridElements?.infoWithStyle?.restaurants
  );
}
const handleSearch = () =>{
  const searchList = listOfRestaurant.filter((res) =>
  res?.info?.name.toLowerCase().includes(searchInput.toLowerCase()));
  setFilteredRes(searchList);
  setSearchInput('');
};


  const handleTopRes = () =>{
    const filteredTop =listOfRestaurant.filter((res)=>res.info.avgRating >= 4.5)
    setListOfRestauratnt(filteredTop)
  }
  return listOfRestaurant.length ===0 ? (
    <Shimmer/>
  ):(
    <div className="Main-container">
      <div className="serach-container">
        <div className="search-contaier">
      <input type="text" placeholder="Search" value={searchInput} 
      onChange={(e) =>setSearchInput(e.target.value)}/>
      <button onClick={handleSearch}>search</button>
      </div>
      <button className="rated-btn" onClick={handleTopRes}>Top Rated Restaurant</button>
</div>
      <div className="res-container">
        {listOfRestaurant.map((restaurant) =>(
          <RestaurantCard key={restaurant.info.id} RestData={restaurant}/>
        ))}
      </div>
    </div>
  );
};
export default MainContent;
