

const Contact =() =>{
    <div>
        <h1>contact us</h1>
    </div>
}

export default Contact;