import { useEffect, useState } from "react"
import Shimmer from "./Shimmer"



const RestaruantMenu =() =>{
    const[resData,setResData] = useState(null);
    useEffect(() =>{
        fetchResData();

    },[]);
const fetchResData = async () =>{
    const data = await fetch("https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=18.53914&lng=73.9046867&restaurantId=10290&catalog_qa=undefined&submitAction=ENTER"

    );
    const jsonData =await data.json()
    setResData(jsonData.data);

};
const {name,cuisines,costForTwo,costForTwoMessage,locality,totalRatingsStrin,sla,avgRating} =resData?.card[2]?.card?.card?.info;
if (resData===null) return <shimmer/>

    return(
        <div>
            <h1>Menu Items</h1>
            <ul>
                <li>Burger</li>
                <li>Burger</li>
                <li>Burger</li>
            </ul>
        </div>
    )
}