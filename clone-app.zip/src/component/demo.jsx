export const DemoComponent = (props) =>{
    console.log(props);
    const {name} = props;
    return <h1>hello {name}, thisis react!</h1>;
    
};