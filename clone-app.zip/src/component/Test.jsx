import React from "react";
import { useState } from "react";
const TestComponent = () =>{
    const[testData, setTestData] = useState("testing");
    return(
        <div>
            <h1>{testData}</h1>
            <button onClick={()=>setTestData("testing not done")}>check</button>
        </div>
    );
};

export default TestComponent;