import { useState } from "react";
import ResLogo from "../assets/res-logo.png";
import { Link } from "react-router-dom";

const Header = () => {
  const [showStatus, setShowStatus] = useState("sign In");
  const handleSignIn = () => {
    showStatus === "sign In"
      ? setShowStatus("sigh out")
      : setShowStatus("sign In");
  };

  return (
    <div className="header-container">
      <div className="log-container">
        <img src={ResLogo} alt="logo" width="100" height="100" />
      </div>
      <div className="nav-items">
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/contact">Contact Us</Link>
          </li>
          <button className="sign-btn" onClick={handleSignIn}>
            {showStatus}{" "}
          </button>
        </ul>
      </div>
    </div>
  );
};
export default Header;
