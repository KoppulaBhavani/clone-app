import { useState } from "react"

const Hello =()=>{
    const [currentState, setCurrentState]=  useState("hello");
    const handleClick=()=>{
        currentState==="hello" ? setCurrentState("Goodbye") :setCurrentState("hello");

    };

    return(
        <div>
        <button className= "hellobtn"
       onClick={handleClick}>{currentState}</button>
        </div>
    )

}
export default Hello;