import { useRouteError } from "react-router-dom";
import ErrorLogo from "../assets/error-logo.jpeg";



const Error =()=>{
    const error = useRouteError();
    return(
        <div className="error-contaier">
            <h1>OOPS! PAGE NOT FOUND</h1>
            <p>YOU MUST HAVE PICKED THE WRONG DOOR.</p>
            <img src={ErrorLogo} alt="Error-Img" height="400px" width="400px"/>
            <h3>
                {error.status} : {error.statusText}
            </h3>

        </div>
    )
}

export default Error;