import ResLogo from "../assets/res-logo.png"
//import FaceBookLogo from "../assets/facebook.png"

const Footer=()=>{
return(
    <div className="footer-container">
        
         <div className="log-container">
        <img src={ResLogo} alt="logo" width="100" height="100"/>
        <div className="footerlogotext">© 2025 Swiggy Limited</div>
        </div>
        <div className="innerdiv">
            <ul >
                <div>
                    <li className="innerfootertext">Company</li>
                </div>
                <li>About Us</li>
                <li>Investor Relations</li>
                <li>Careers</li>
                <li>Team</li>
                <li>Swiggy One</li>
                <li>Swiggy Instamart</li>
                <li>Swiggy Dineout</li>
            </ul>
            <ul >
                <div>
                    <li className="innerfootertext">Contact us</li>
                </div>
                <li>Help & Support</li>
                <li>Investor Relations</li>
                <li>Partner with us</li>
                <li>Team</li>
                <li>Ride with us</li>
                <div>
                    <li className="innerfootertext">Legal</li>
                </div>
                <li>Terms & Conditions</li>
                <li>Cookie Policy</li>
                <li>Privacy Policy</li>
            </ul>
            <ul >
                <div>
                    <li className="innerfootertext">Available in:</li>
                </div>
                <li>Hyderabad</li>
                <li>Banglore</li>
                <li>Gurgaom</li>
                <li>Delhi</li>
                <li>Mumbai</li>
                <li>Pune</li>
                <li>
                    <div>
                        <select className="form-select">
                            <option>679 cities</option>
                        </select>
                    </div>
                </li>
            </ul>
            <ul >
                <div>
                    <li className="innerfootertext">Life at Swiggy</li>
                </div>
                <li>Explore with Swiggy</li>
                <li>Swiggy News</li>
                <li>Snackables</li>
                <div>
                    <li className="innerfootertext">Social links</li>
                </div>
                <div className="icon-css">
                 
                 <i className="bi bi-instagram"></i>
                 <i className="bi bi-facebook"></i>
                 <i className="bi bi-whatsapp"></i>
                 <i className="bi bi-twitter-x"></i>
                 <i className="bi bi-pinterest"></i>
                </div>
            </ul>
        

        </div>
        <div>

        </div>

 
 
    </div>
)
}
export default Footer;