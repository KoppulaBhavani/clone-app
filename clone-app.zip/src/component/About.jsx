

const About = () =>{
    <div>
        <h1>ABOUT US</h1>
        <p>Swiggy is a new-age consumer-first organization offering an easy-to-use convenience platform, accessible through a unified app.</p>
    </div>
    
}

export default About;