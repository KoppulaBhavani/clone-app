export const UserCard = (props) =>{
    console.log(props);
    
    return <div>
    <h1>hello {props.name} , this is my!</h1>
    <h6>my {props.name} and {props.email}, this is my </h6>
    </div>
    
}